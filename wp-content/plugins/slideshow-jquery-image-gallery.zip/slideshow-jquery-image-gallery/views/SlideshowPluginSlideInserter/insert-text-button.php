
<input type="button" id="slideshow-insert-text-slide" class="button" value="<?php _e('Text slide', 'slideshow-plugin'); ?>" />
