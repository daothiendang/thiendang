
<?php 
/**
 * The template for displaying Category pages
 * Imonthemes
 */


get_header(); ?>
<div class="row">
<div class="large-12 ">
 
<div id="content" >
<?php get_template_part(''.$isis = of_get_option('layout1_images').''); ?>

</div>
</div>
</div>

<?php get_footer(); ?>